<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Service;

class GenerateSitemap extends Command
{
    protected $signature = 'sitemap:generate';

    protected $description = 'Generate sitemap.xml';

    public function handle()
    {
        $urls = [];

        /*
        |--------------------------------------------------------------------------
        | Static Pages
        |--------------------------------------------------------------------------
        */

        $staticPages = [
            [
                'url' => '/',
                'priority' => '1.0',
                'changefreq' => 'daily',
            ],
            [
                'url' => '/about',
                'priority' => '0.8',
                'changefreq' => 'monthly',
            ],
            [
                'url' => '/services',
                'priority' => '0.9',
                'changefreq' => 'weekly',
            ],
            [
                'url' => '/contact',
                'priority' => '0.7',
                'changefreq' => 'monthly',
            ],
        ];

        foreach ($staticPages as $page) {
            $urls[] = [
                'loc' => url($page['url']),
                'priority' => $page['priority'],
                'changefreq' => $page['changefreq'],
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Services
        |--------------------------------------------------------------------------
        */

        Service::where('status', 1)
            ->get()
            ->each(function ($service) use (&$urls) {

                $urls[] = [
                    'loc' => url('/services/' . $service->slug),
                    'priority' => '0.7',
                    'changefreq' => 'weekly',
                    'lastmod' => optional($service->updated_at)->toAtomString(),
                ];
            });

        /*
        |--------------------------------------------------------------------------
        | Generate XML
        |--------------------------------------------------------------------------
        */

        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;

        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

        foreach ($urls as $item) {

            $xml .= "    <url>" . PHP_EOL;

            $xml .= "        <loc>" .
                htmlspecialchars($item['loc'], ENT_XML1, 'UTF-8') .
                "</loc>" . PHP_EOL;

            if (!empty($item['lastmod'])) {
                $xml .= "        <lastmod>" .
                    $item['lastmod'] .
                    "</lastmod>" . PHP_EOL;
            }

            $xml .= "        <changefreq>" .
                $item['changefreq'] .
                "</changefreq>" . PHP_EOL;

            $xml .= "        <priority>" .
                $item['priority'] .
                "</priority>" . PHP_EOL;

            $xml .= "    </url>" . PHP_EOL;
        }

        $xml .= '</urlset>';

        /*
        |--------------------------------------------------------------------------
        | Save sitemap
        |--------------------------------------------------------------------------
        */

        file_put_contents(
            public_path('sitemap.xml'),
            $xml
        );

        $this->info('Sitemap generated successfully!');
        $this->info('Location: ' . public_path('sitemap.xml'));
        $this->info('URL: ' . url('sitemap.xml'));

        return Command::SUCCESS;
    }
}
