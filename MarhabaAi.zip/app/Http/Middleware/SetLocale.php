<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $locale = $request->route('locale');

        // Only allow supported languages
        if (!in_array($locale, ['en', 'ar'], true)) {
            $locale = 'en';
        }

        // Set Laravel application locale
        app()->setLocale($locale);

        // Make the current locale automatically available
        // when generating routes with route()
        URL::defaults([
            'locale' => $locale,
        ]);

        return $next($request);
    }
}
